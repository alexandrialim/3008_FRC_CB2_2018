package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_LRL_Scale extends CommandGroup{
	public  Right_LRL_Scale() {
		/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		addSequential(new SetWristSetpoint(Wrist.PICKUP));
		addSequential(new OpenClaw());*/
		
		 addSequential(new DriveForward_AutoCommand(318, 0.75));
		 addSequential(new DriveLeft_AutoCommand(90, 0.75));
		 addSequential(new DriveForward_AutoCommand(24, 0.75));
		 addSequential(new GuillotineScale_Command());
		 addSequential(new clawControlClose_Command());
		 addSequential(new DriveLeft_AutoCommand(90, 0.75));
		//MOve forword 26.5ft
		//turn left 90
		//raise intake into scale
		//outtake cube into scale
		//turn left 90
		//end program
	
	}
}