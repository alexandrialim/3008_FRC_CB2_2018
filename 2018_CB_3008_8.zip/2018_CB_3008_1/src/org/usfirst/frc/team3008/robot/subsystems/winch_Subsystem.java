package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;

import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.command.Subsystem;

public class winch_Subsystem extends Subsystem{
	public static Spark WS = new Spark(RobotMap.winch);

	public void WinchUp(){
		WS.set(-1);
	}
	public void WinchStop(){
		WS.set(0);
	}
	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(null);
		
	}

}
