package org.usfirst.frc.team3008.robot.subsystems;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.command.Subsystem;

public class Switches_Subsystem extends Subsystem {
	public DigitalInput SWRB = new DigitalInput(1);
	
	public boolean getSwitchRB(){
		return SWRB.get();
	}
	
	
	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(null);
		
	}

}
