package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class DriveForward_AutoCommand extends Command{
	public double power;
	public double d;
	public double totalDistance = 0;
	public double error = 0;
	public double kp = 0.00006; // start num change if necessary 
	public double masterpow = 0 ;
	public double slavepow = 0;
	public double poweradjustment = 0;
	public double leftposition = 0;
	public double rightposition = 0 ;

	public DriveForward_AutoCommand(double distance, double pow){
		requires(Robot.Drive_Subsystem);
		d = distance;
		power = pow;
			
		}
	
	protected void initialize() {
		masterpow = -power;
		slavepow = -power;
		Robot.Drive_Subsystem.driveTrain(masterpow, slavepow);
		totalDistance = 0;
		Robot.Drive_Subsystem.resetEnc();
	}
	
	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
	/*	leftposition = Robot.Drive_Subsystem.getEncL();
		rightposition = Robot.Drive_Subsystem.getEncR();
	error = Math.abs(leftposition) - Math.abs(rightposition);
		
		
		//poweradjustment = 0.00023 * (Math.abs(error) / (Math.abs(leftposition) + Math.abs(rightposition)));
		
		if (error < 0 || error > 0){

			poweradjustment = slavepow * kp;
			
			if(Math.abs(leftposition) < Math.abs(rightposition) ){
				slavepow -= poweradjustment;
			}
			else if(Math.abs(leftposition)  > Math.abs(rightposition)){
				slavepow += poweradjustment;
			}
			
		}
		//slavepow += poweradjustment;
		
		*/
		//Robot.Drive_Subsystem.driveTrain(masterpow, slavepow);
		totalDistance += Math.abs(Robot.Drive_Subsystem.getEncLDistance());
		System.out.println(totalDistance);

	}
	
	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		return (totalDistance > d);
	}
	
	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.Drive_Subsystem.driveTrain(0, 0);
		Robot.Drive_Subsystem.resetEnc();
		
	}
	
	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
	}
}
