package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.buttons.Button;

public class POVButton extends Button{

	 private GenericHID joystick;
	    public POVButton(GenericHID joystick, double i) {
	        this.joystick = joystick;
	    }
	    public boolean get() {
	        return this.joystick.getPOV() != 1;
	    }
	

}
