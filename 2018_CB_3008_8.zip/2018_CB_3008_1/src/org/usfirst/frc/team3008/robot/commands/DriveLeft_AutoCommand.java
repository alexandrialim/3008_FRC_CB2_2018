package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

public class DriveLeft_AutoCommand extends Command{
	public double power;
	public double degree = 0;
	public int multiplier = 4;
	public double convdegrees = 0;
	public double masterpow = 0;
	public double slavepow = 0;
	
	
	public DriveLeft_AutoCommand(double degrees, double pow){
		requires(Robot.Drive_Subsystem);
		power = pow;
		convdegrees = multiplier*degrees;
		}
	
	protected void initialize() {
		Robot.Drive_Subsystem.resetEnc();
		masterpow = -power;
		slavepow = power;
		Robot.Drive_Subsystem.driveTrain(masterpow, slavepow);
	}
	
	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
	}
	
	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		double finalnumL = Math.abs(Robot.Drive_Subsystem.getEncL());
		double finalnumR = Math.abs(Robot.Drive_Subsystem.getEncR());
		return (finalnumL > convdegrees && finalnumR > convdegrees);
	}
	
	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.Drive_Subsystem.driveTrain(0, 0);
	}
	
	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
	}
}