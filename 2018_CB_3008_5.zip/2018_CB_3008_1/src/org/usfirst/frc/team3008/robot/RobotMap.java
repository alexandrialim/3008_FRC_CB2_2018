package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Spark;

/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////		//				//		//////////////
//////	  	 //			//			 //			   //		//
//////		 //			//			  //		  //		//
//////////// //			//			   //		 //			////////
///////		//				//				//		//			//
//////	 //				//				 //	   //			//
//////	   //			//				  //  //			//
///////			//	     //		///////////			   ////				/////////////
///////////////////////////////////////////////////////////////////////////////////////////
//Front Drive Wheel Port Numbers //

public static final int L1 = 1;
public static final int R1 = 2;

////////////////////////////////////////////////////////////////
//Back Drive Wheel Port Numbers //

public static final int L2 = 3;
public static final int R2 = 4;

/////////////////////////////////////////////////////////////////////////////////////////////
//Other Variables // // those are examples....
public static final int claw = 0;
public static final int claw1 = 0;
public static final int Arm = 5; 
public static final int Elevator = 7;

///////////////////////////////////////////////////
public static final int GuillotineEncA = 0;
public static final int GuillotineEncB = 1;
public static final int encLA = 4;
public static final int encLB = 5;

public static final int encRA = 2;
public static final int encRB = 3;
/////////////////////////////////////////////////
public static final int AirCompress = 6;

///////////////////////////////////////////
public static final int DSF = 2; // Forward
public static final int DSR = 1; // Reverse

///////////////////////////////////
public static final int SS = 0; // single solenoid
///////////////////////////////////////////////////
public static final int SWRB = 1;
public static final int SW1 = 2;
public static final int SW2 = 3;
public static final int SW3 = 4;


/////////////////////////////////////
public static final int dioR = 9;
public static final int dioG = 7;
public static final int dioY = 8;

}
