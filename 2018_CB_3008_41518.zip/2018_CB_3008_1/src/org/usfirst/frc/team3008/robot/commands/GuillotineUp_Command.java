package org.usfirst.frc.team3008.robot.commands;


import org.usfirst.frc.team3008.robot.OI;
import org.usfirst.frc.team3008.robot.POVButton;
import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.command.Command;

public class GuillotineUp_Command extends Command{
	
	public GuillotineUp_Command(){
		requires(Robot.Guillotine_Subsystem);
	//	DriverStation.getInstance().reportWarning("hi1",false);
	}

	protected void initialize() {
	}

	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
		
		Robot.Guillotine_Subsystem.setSpeed();
	//	DriverStation.getInstance().reportWarning("hi2",false);
	}

	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		return false;
	}

	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.Guillotine_Subsystem.stop();
	}

	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
		end();
	}

}
