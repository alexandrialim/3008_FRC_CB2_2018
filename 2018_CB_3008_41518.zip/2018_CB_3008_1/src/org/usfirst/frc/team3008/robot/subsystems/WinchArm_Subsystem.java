package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.command.Subsystem;

public class WinchArm_Subsystem extends Subsystem {
	static Spark Wa = new Spark(RobotMap.WArm);
	
	public WinchArm_Subsystem(){
	}
	
	public void forward(){ 
		
		Wa.set(0.25);
		//return true;
	}
	public void stop(){ 
		Wa.set(0);
		//return true;
	}
	public void Back(){ 
		Wa.set(-0.25);
		//return true;
	}

	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(null);
		
	}
	
}

