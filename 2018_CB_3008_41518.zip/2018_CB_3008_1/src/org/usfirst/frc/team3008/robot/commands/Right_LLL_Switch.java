package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_LLL_Switch extends CommandGroup {
	 public  Right_LLL_Switch() {
	/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
	addSequential(new SetWristSetpoint(Wrist.PICKUP));
	addSequential(new OpenClaw());*/
		 addSequential(new DriveForward_AutoCommand(84, 0.75));
		 addSequential(new DriveLeft_AutoCommand(90, 0.75));
		 addSequential(new DriveForward_AutoCommand(240, 0.75));
		 addSequential(new DriveLeft_AutoCommand(90, 0.75));
		 addSequential(new DriveForward_AutoCommand(24, 0.75));
		 addSequential(new GuillotineSwitch_Command(2));
		 addSequential(new clawControlClose_Command());
	//move forwaard 7ft
	//turn left 90
	//move forward 20ft
	//turn left 90
	//move forward 2ft
	//turn left 90
	// move forward 2ft
	//raise intake into switch
	//outake cube into switch
	//end program
		 
	 }
}
