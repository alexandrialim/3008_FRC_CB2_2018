package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_Any_Cross extends CommandGroup {

    public  Right_Any_Cross() {
   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
    	addSequential(new OpenClaw());*/
    	/*
    	 addSequential(new clawControl_AutoCommand());
    	 addSequential(new DriveLeft_AutoCommand(360, 0.70));
    	 addSequential(new DriveForward_AutoCommand(1060, 0.80));
    	 addSequential(new clawControl_OutAutoCommand());
    	 */
    	
    	addSequential(new DriveForward_AutoCommand(1060, 0.80));//1060
    	//addSequential(new basicTimeDriveF());
    	
    	
    	//Drive Forward
    	//End program
    	
    }

}