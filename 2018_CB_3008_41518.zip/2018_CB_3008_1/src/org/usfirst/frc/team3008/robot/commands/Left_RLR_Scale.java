package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Left_RLR_Scale extends CommandGroup {

	
	 public  Left_RLR_Scale() {
		   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
		    	addSequential(new OpenClaw());*/
		 	addSequential(new DriveForward_AutoCommand(318, 0.75));
			addSequential(new DriveRight_AutoCommand(90, 1));
			addSequential(new GuillotineScale_Command());
			addSequential(new clawControl_OutAutoCommand(2));
			addSequential(new DriveLeft_AutoCommand(90, 1));
			// * Move forward 26.5ft
			// * Turn Right 90
			//* Raise intake to Scale height
			//* Outtake cube into scale
			 //* turn left 90
			 //* end program 
	 }
			 
}
