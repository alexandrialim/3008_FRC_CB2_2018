package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Left_Any_Cross extends CommandGroup {

	public  Left_Any_Cross() {
	    	addSequential(new DriveForward_AutoCommand(1060, 1));
		//Drive Forward
		//End program
		
	    }
	}
