package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Left_RRR_Switch extends CommandGroup {
	
	 public  Left_RRR_Switch() {
		   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
		    	addSequential(new OpenClaw());*/
		 	addSequential(new DriveForward_AutoCommand(84, 0.75));
			addSequential(new DriveRight_AutoCommand(90, 0.75));
			addSequential(new DriveForward_AutoCommand(240, 0.75));
			addSequential(new DriveRight_AutoCommand(90, 0.75));
			addSequential(new DriveForward_AutoCommand(24, 0.75));
			addSequential(new DriveRight_AutoCommand(90, 0.75));
			addSequential(new DriveForward_AutoCommand(24, 0.75));
			
			addSequential(new GuillotineSwitch_Command(2));
			addSequential(new clawControlClose_Command());
			
		 //* Move forward 7ft
		 //* turn Right 90
		 //* move Forward 20ft
		 //* turn right 90
		 //* move forward 2ft
		 //* turn right 90
		 //* move forward 2ft
		 //* raise intake to switch height
		 //* end program
	 } 
}
