package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.OI;
import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

public class WArmBack extends Command{

public WArmBack(){
		

		requires(Robot.WinchArm_Subsystem);
		
	}

	protected void initialize() {
	}

	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
		Robot.WinchArm_Subsystem.Back();
	}

	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		return false;
	}

	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.WinchArm_Subsystem.stop();
	}

	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
	}

}
