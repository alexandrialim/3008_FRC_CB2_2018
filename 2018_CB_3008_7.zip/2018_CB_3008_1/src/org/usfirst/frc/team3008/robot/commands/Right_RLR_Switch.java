package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_RLR_Switch extends CommandGroup{
	
	 public  Right_RLR_Switch() {
	/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
	addSequential(new SetWristSetpoint(Wrist.PICKUP));
	addSequential(new OpenClaw());*/
	
	//drive forward 13ft
	//turn left 90
	//drive forward 2ft
	//raise intake to switch
	//outtake cube into switch
	//turn right 90
	//drive forward 6ft
	//end programs

	 }
}
