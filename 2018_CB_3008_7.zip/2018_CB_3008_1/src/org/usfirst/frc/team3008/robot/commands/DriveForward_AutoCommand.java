package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class DriveForward_AutoCommand extends Command{
	public double power;
	public double d;
	public double totalDistance = 0;
	public double error = 0;
	public double kp = 0.2; // start num change if necessary 
	public double masterpow = 0 ;
	public double slavepow = 0;

	public DriveForward_AutoCommand(double distance, double pow){
		requires(Robot.Drive_Subsystem);
		d = distance;
		power = pow;
			
		}
	
	protected void initialize() {
		masterpow = power;
		slavepow = power;
		Robot.Drive_Subsystem.driveTrain(masterpow, slavepow);
		totalDistance = 0;
	}
	
	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
		error = Robot.Drive_Subsystem.getEncL() - Robot.Drive_Subsystem.getEncR();
		slavepow += error * kp;
		Robot.Drive_Subsystem.driveTrain(masterpow, slavepow);
		totalDistance += Math.abs(Robot.Drive_Subsystem.getEncLDistance());
		Robot.Drive_Subsystem.resetEnc();
	}
	
	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		return (totalDistance > d);
	}
	
	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.Drive_Subsystem.driveTrain(0, 0);
	}
	
	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
	}
}
