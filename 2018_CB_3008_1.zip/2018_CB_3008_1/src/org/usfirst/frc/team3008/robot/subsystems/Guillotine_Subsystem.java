package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.command.WaitUntilCommand;

public class Guillotine_Subsystem extends Subsystem{
	Spark LiftS = new Spark(RobotMap.Elevator);
	Encoder GEnc = new Encoder(RobotMap.GuillotineEncA, RobotMap.GuillotineEncB, false, EncodingType.k4X);

	public Guillotine_Subsystem(){
	}
	
	public void getGEnc(){
		GEnc.get();
	}
	public double setGEnc(double i){
		return i;
	}
	public void Up(){ 
		LiftS.set(1);
	}
	public void stop(){ 
		LiftS.set(0);
	}
	public void Down(){ 
		LiftS.set(-1);
	}
/*	public void Switch(){
		while(GEnc.get() < 720){
			LiftS.set(1);
		}
	}
	public void Scale(){
		while(GEnc.get() < 1500){
			LiftS.set(1);
		}
	}
	public void Ground(){
		while(GEnc.get() < 0){
			LiftS.set(1);
		}
	}*/
	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(null);
		
	}

}
