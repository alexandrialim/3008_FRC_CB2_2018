
public class Left_LRL_Switch extends CommandGroup {

	public  Left_LRL_Switch() {
   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
    	addSequential(new OpenClaw()); */
		
		//* Move forward 13ft
		//* turn right 90
		//* move forward 2ft
		//* raise intake to switch height
		//* outake cube into switch height
		//* turn left 90
		//* move forward 6ft
		//* end program
    }
	
}
