
public class Right_RLR_Switch extends CommandGroup{
	
	 public  Right_RLR_Switch() {
	/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
	addSequential(new SetWristSetpoint(Wrist.PICKUP));
	addSequential(new OpenClaw());*/
	
		 addSequential() //drive forward 13ft
		 addSequential() //turn left 90
		 addSequential()//drive forward 2ft
		 addSequential() //raise intake to switch
		 addSequential() //outtake cube into switch
		 addSequential() //turn right 90
		 addSequential() //drive forward 6ft
		 addSequential() //end programs

	 }
}
