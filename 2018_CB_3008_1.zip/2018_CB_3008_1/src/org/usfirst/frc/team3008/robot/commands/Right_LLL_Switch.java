
public class Right_LLL_Switch extends {
	 public  Right_LLL_Switch() {
	/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
	addSequential(new SetWristSetpoint(Wrist.PICKUP));
	addSequential(new OpenClaw());*/
	
		 addSequential() //move forwaard 7ft
		 addSequential() //turn left 90
		 addSequential() //move forward 20ft
		 addSequential() //turn left 90
		 addSequential() //move forward 2ft
		 addSequential()	//turn left 90
		 addSequential() // move forward 2ft
		 addSequential() //raise intake into switch
		 addSequential() //outake cube into switch
		 addSequential() //end program
		 
	 }
}
