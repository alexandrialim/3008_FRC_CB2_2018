
public class Left_RRR_Switch extends CommandGroup {
	
	 public  Left_RRR_Switch() {
		   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
		    	addSequential(new OpenClaw());*/
		 
		 addSequential(new DriveForward_AutoCommand(84, 0.75));  //* Move forward 7ft
		 addSequential(new DriveRight_AutoCommand(90, 0.75)); //* turn Right 90
		 addSequential(new DriveForward_AutoCommand(240, 0.75));  //* move Forward 20ft
		 addSequential(new DriveRight_AutoCommand(90, 0.75)); //* turn right 90
		 addSequential(new DriveForward_AutoCommand(24, 0.75)); //* move forward 2ft
		 addSequential(new DriveRight_AutoCommand(90, 0.75)); //* turn right 90
		 addSequential(new DriveForward_AutoCommand(24, 0.75));  //* move forward 2ft
		 addSequential(new GuillotineSwitch_AutoCommand); //* raise intake to switch height
		 //* end program
		 
}
