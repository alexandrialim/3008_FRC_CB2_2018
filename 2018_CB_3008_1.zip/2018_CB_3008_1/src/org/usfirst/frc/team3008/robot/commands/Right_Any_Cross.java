

public class Right_Any_Cross extends CommandGroup {

    public  Right_Any_Cross() {
   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
    	addSequential(new OpenClaw());*/
    	
    	addSequential(new DriveForward_AutoCommand(19, 0.75)) 	//Drive Forward
    	 //End program
    	
    }
}