
public class Right_LRL_Scale {
	public  Right_LLL_Switch() {
		/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		addSequential(new SetWristSetpoint(Wrist.PICKUP));
		addSequential(new OpenClaw());*/
		
		//MOve forword 26.5ft
		//turn left 90
		//raise intake into scale
		//outtake cube into scale
		//turn left 90
		//end program
	
	}
}