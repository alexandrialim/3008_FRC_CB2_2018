
public class Right_LRL_Scale {
	public  Right_LLL_Switch() {
		/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		addSequential(new SetWristSetpoint(Wrist.PICKUP));
		addSequential(new OpenClaw());*/
		
		addSequential() //MOve forword 26.5ft
		addSequential() //turn left 90
		addSequential() //raise intake into scale
		addSequential() //outtake cube into scale
		addSequential() //turn left 90
		addSequential() //end program
	
	}
}