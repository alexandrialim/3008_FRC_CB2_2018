
public class Left_RLR_Scale extends CommandGroup {

	
	 public  Left_RLR_Scale() {
		   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
		    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
		    	addSequential(new OpenClaw());*/
		 
		 addSequential(new DriveForward_AutoCommand(318, 0.75)); // * Move forward 26.5ft
		 addSequential(new DriveRight_AutoCommand(90, 0.75)); // * Turn Right 90
		 addSequential(new GuillotineScale_Command); //* Raise intake to Scale height
		 addSequential(new Guillotine); //* Outtake cube into scale
		 addSequential(new DriveLeft_AutoCommand(90, 0.75)); //* turn left 90
		 //* end program 
			 
}
