
public class Left_Any_Cross extends CommandGroup {

	public  Right_Any_Cross() {
		
		addSequential(new DriveForward_AutoCommand(246, 0.75)); //Drive Forward
		 //End program
		
	    }
	}
