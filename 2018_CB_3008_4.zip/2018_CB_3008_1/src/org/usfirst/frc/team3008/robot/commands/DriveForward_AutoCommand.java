package org.usfirst.frc.team3008.robot.commands;

import org.usfirst.frc.team3008.robot.Robot;
import org.usfirst.frc.team3008.robot.subsystems.Enc_Subsystem;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class DriveForward_AutoCommand extends CommandGroup {

public DriveForward_AutoCommand(){
		

		requires(Robot.Drive_Subsystem);
		
		
	}
	protected void initialize() {
		Robot.Enc_Subsystem.resetEnc();
	}
	
	// Called repeatedly when this Command is scheduled to run
	@Override
	protected void execute() {
		//Robot.Enc_Subsystem.setEncL(6204.26);
		//Robot.Enc_Subsystem.setEncR(6204.26);
		while(Robot.Enc_Subsystem.getEncL() <= 6204.26 && Robot.Enc_Subsystem.getEncR() <= 6204.26){ //PLSS TESTTT
		Robot.Drive_Subsystem.driveTrain(1.0, 1.0); 
			if(Robot.Enc_Subsystem.getEncL() > 6204.27 && Robot.Enc_Subsystem.getEncR() > 6204.27){
				Robot.Drive_Subsystem.driveTrain(0.0, 0.0);
			}
		}
		
	}
	
	// Make this return true when this Command no longer needs to run execute()
	@Override
	protected boolean isFinished() {
		return false;
	}
	
	// Called once after isFinished returns true
	@Override
	protected void end() {
		Robot.Drive_Subsystem.driveTrain(0, 0);
	}
	
	// Called when another command which requires one or more of the same
	// subsystems is scheduled to run
	@Override
	protected void interrupted() {
	}

}
