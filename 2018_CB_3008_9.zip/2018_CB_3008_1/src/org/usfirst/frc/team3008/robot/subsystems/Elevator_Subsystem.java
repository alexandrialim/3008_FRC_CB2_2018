package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.command.Subsystem;
import org.usfirst.frc.team3008.robot.commands.ElevatorOff_Command;


public class Elevator_Subsystem extends Subsystem {
	public Solenoid SS;

	
	public void Elevator(){
		SS = new Solenoid(RobotMap.SS);

	}
	
	
	
	public void initDefaultCommand() {
		// Set the default command for a subsystem here.
		setDefaultCommand(new ElevatorOff_Command());
	}

}