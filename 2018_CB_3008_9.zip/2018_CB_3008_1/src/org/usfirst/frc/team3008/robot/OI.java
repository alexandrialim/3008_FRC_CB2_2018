package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import edu.wpi.first.wpilibj.buttons.Trigger;




//AKA JoyStick 


import org.usfirst.frc.team3008.robot.commands.GuillotineUp_Command;
import org.usfirst.frc.team3008.robot.commands.PnClawOpen_Command;
import org.usfirst.frc.team3008.robot.commands.PnClawClose_Command;
import org.usfirst.frc.team3008.robot.commands.GuillotineStop_Command;
import org.usfirst.frc.team3008.robot.commands.GuillotineDown_Command;
import org.usfirst.frc.team3008.robot.commands.GuillotineUp_Command;
import org.usfirst.frc.team3008.robot.commands.SingleSol_Command;
import org.usfirst.frc.team3008.robot.commands.SingleSol_stopCommand;
import org.usfirst.frc.team3008.robot.commands.WinchStop_Command;
import org.usfirst.frc.team3008.robot.commands.WinchUp_Command;
import org.usfirst.frc.team3008.robot.commands.clawControlClose_Command;
import org.usfirst.frc.team3008.robot.commands.clawControlOpen_Command;
import org.usfirst.frc.team3008.robot.commands.clawControlStop_Command;


/**
 * This class is the glue that binds the controls on the physical operator
 * interface to the commands and command groups that allow control of the robot.
 */
public class OI {
	  static Joystick joy1 = new Joystick(0);
	  
	  Button clawOpen = new JoystickButton(joy1, 1); // rollers
	  Button clawClose = new JoystickButton(joy1, 3); // rollers
	//  Button PnClawOpen = new JoystickButton(joy1, 4);
	  
	/*  Button GuillotineUp = new JoystickButton(joy1, 6); //RT
	  Button GuillotineDown = new JoystickButton(joy1, 5); //LT*/
	  
	  Button winchUp = new JoystickButton(joy1, 7);// middle left top button
	  Button SSOpen = new JoystickButton(joy1, 2); // RB

	  
	  
	 public OI() {
	//	 DriverStation.getInstance().reportWarning("hi",false);
		 GuillotineUp_Command g = new GuillotineUp_Command();
		 
		 clawOpen.whenInactive(new clawControlStop_Command());
		 clawOpen.whenPressed( new clawControlOpen_Command());	
		 clawClose.whenInactive(new clawControlStop_Command());
		 clawClose.whenPressed( new clawControlClose_Command());
		 
	/*	 GuillotineUp.whenInactive(new GuillotineStop_Command());
		 GuillotineUp.whenActive(new GuillotineUp_Command());	
		 GuillotineDown.whenInactive(new GuillotineStop_Command());
		 GuillotineDown.whenActive(new GuillotineDown_Command());*/
		 winchUp.whenPressed(new WinchUp_Command());
		 winchUp.whenInactive(new WinchStop_Command());
		 
		// PnClawOpen.whenPressed(new PnClawOpen_Command());
		// PnClawOpen.whenInactive(new PnClawClose_Command());
	/*	 DSOpen.whenInactive(new Sol_StopCommand());
		 DSOpen.whenPressed(new Sol_OpenCommand());*/
		 SSOpen.whenInactive(new SingleSol_stopCommand());
		 SSOpen.whenPressed(new SingleSol_Command());
	 }
	  
	  
	

	/*
    public static double deadzone(double d){
    	if (Math.abs(d)< 0.15){
    		return 0;
    	}
    	return (d / Math.abs(d)) * ((Math.abs(d) - 0.15) /(1 - 0.15));
    }
    */
    public static double getLeftStickY() {
        return (joy1.getRawAxis(1));
    }
    
    public static double getRightStickY() {
        return (joy1.getRawAxis(5));
    }
   
    public static double getLeftTrigger() {
        return (joy1.getRawAxis(2));
    }
    
    public static double getRightTrigger() {
       return (joy1.getRawAxis(3));
    }
    
 /*   public static double TR(){
    	return (joy1.getRawAxis(3));
    }
    public static double TL(){
    	return (joy1.getRawAxis(2));
    }
    public class Triggers extends Trigger{
    	private final Joystick joy1;
    	public Triggers(Joystick joy1){
    		this.joy1 = joy1;
    	}
		@Override
		public boolean get() {
			return joy1.getPOV() != -1;
		}
    	
    }*/
}
    
	//// CREATING BUTTONS
	// One type of button is a joystick button which is any button on a
	//// joystick.
	// You create one by telling it which joystick it's on and which button
	// number it is.
	// Joystick stick = new Joystick(port);
	// Button button = new JoystickButton(stick, buttonNumber);

	// There are a few additional built in buttons you can use. Additionally,
	// by subclassing Button you can create custom triggers and bind those to
	// commands the same as any other Button.

	//// TRIGGERING COMMANDS WITH BUTTONS
	// Once you have a button, it's trivial to bind it to a button in one of
	// three ways:

	// Start the command when the button is pressed and let it run the command
	// until it is finished as determined by it's isFinished method.
	// button.whenPressed(new ExampleCommand());

	// Run the command while the button is being held down and interrupt it once
	// the button is released.
	// button.whileHeld(new ExampleCommand());

	// Start the command when the button is released and let it run the command
	// until it is finished as determined by it's isFinished method.
	// button.whenReleased(new ExampleCommand());

