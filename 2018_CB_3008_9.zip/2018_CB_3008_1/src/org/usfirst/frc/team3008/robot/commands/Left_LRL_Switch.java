package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Left_LRL_Switch extends CommandGroup {

	public  Left_LRL_Switch() {
   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
    	addSequential(new OpenClaw()); */
		
		addSequential(new DriveForward_AutoCommand(156, 0.75));
		addSequential(new DriveRight_AutoCommand(90, 0.75));
		addSequential(new DriveForward_AutoCommand(24, 0.75));
		
		addSequential(new GuillotineSwitch_Command);
		addSequential(new clawControl_OutAutoCommand);
		
		addSequential(new DriveLeft_AutoCommand(90, 0.75));
		addSequential(new DriveForward_AutoCommand(72, 0.75));
		//* Move forward 13ft
		//* turn right 90
		//* move forward 2ft
		//* raise intake to switch height
		//* outake cube into switch height
		//* turn left 90
		//* move forward 6ft
		//* end program
    }
	
}
