package org.usfirst.frc.team3008.robot;

import edu.wpi.cscore.UsbCamera;
import edu.wpi.first.wpilibj.CameraServer;
import org.opencv.core.Mat;
import org.opencv.core.RotatedRect;



public class Camera {
	
	
	UsbCamera cam;
	
	public void camInit(){
		this.cam = CameraServer.getInstance().startAutomaticCapture("vision", 0);
		this.cam.setFPS(30); // Frames per a second
		this.cam.setResolution(1280, 720); //width and height of frame that camera sees as a whole image
		this.cam.setExposureManual(50); // amount of light the camera captures when photo is taken.
	}

}
	
