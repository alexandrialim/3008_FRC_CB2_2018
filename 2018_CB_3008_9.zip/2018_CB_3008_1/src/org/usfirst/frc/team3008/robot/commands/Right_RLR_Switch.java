package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_RLR_Switch extends CommandGroup{
	
	 public  Right_RLR_Switch() {
	/* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
	addSequential(new SetWristSetpoint(Wrist.PICKUP));
	addSequential(new OpenClaw());*/
	
		 addSequential(new DriveForward_AutoCommand(156, 0.75));
		 addSequential(new DriveLeft_AutoCommand(90, 0.75));
		 addSequential(new DriveForward_AutoCommand(24, 0.75));
		 addSequential(new GuillotineSwitch_Command());
		 addSequential(new clawControlClose_Command());
		 addSequential(new DriveRight_AutoCommand(90, 0.75));
		 addSequential(new DriveForward_AutoCommand(72, 0.75));
	//drive forward 13ft
	//turn left 90
	//drive forward 2ft
	//raise intake to switch
	//outtake cube into switch
	//turn right 90
	//drive forward 6ft
	//end programs

	 }
}
