package org.usfirst.frc.team3008.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class Right_Any_Cross extends CommandGroup {

    public  Right_Any_Cross() {
   /* 	addSequential(new SetElevatorSetpoint(Elevator.TABLE_HEIGHT));
    	addSequential(new SetWristSetpoint(Wrist.PICKUP));
    	addSequential(new OpenClaw());*/
    	addSequential(new DriveForward_AutoCommand);
    	//Drive Forward
    	//End program
    	
    }
}