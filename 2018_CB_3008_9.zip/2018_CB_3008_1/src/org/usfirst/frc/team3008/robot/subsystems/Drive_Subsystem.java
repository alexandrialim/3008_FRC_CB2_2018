package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;
import org.usfirst.frc.team3008.robot.commands.DriveControl_Command;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

public class Drive_Subsystem extends Subsystem {
	
	static Spark R1 = new Spark(RobotMap.R1);
	static Spark R2 = new Spark(RobotMap.R2);
	static Spark L1 = new Spark(RobotMap.L1);
	static Spark L2 = new Spark(RobotMap.L2);
	
	Encoder encL = new Encoder(RobotMap.encLA, RobotMap.encLB, false, EncodingType.k4X);
	Encoder encR = new Encoder(RobotMap.encRA, RobotMap.encRB, false, EncodingType.k4X);
	
	SpeedControllerGroup left = new SpeedControllerGroup(L1, L2);
	SpeedControllerGroup right = new SpeedControllerGroup(R1, R2);
	
	DifferentialDrive m_drive = new DifferentialDrive (left, right);
	
	public double wheelD = 6;
	public double DistancePerPulse = Math.PI*wheelD/360;
	
	 public Drive_Subsystem(){
		 encL.setDistancePerPulse(DistancePerPulse);
		 encR.setDistancePerPulse(DistancePerPulse);
	 }
	
	
	
	public void driveTrain(double leftSpeed, double rightSpeed){
		m_drive.tankDrive(leftSpeed, rightSpeed);
		
	}	
	
	public double getEncRDistance(){ 
		
		return encR.getDistance();
	}
	public double getEncLDistance(){ 
		
		return encL.getDistance();
	}
	public double getEncR(){ 
		
		return encR.get();
	}
	public double getEncL(){ 
		
		return encL.get();
	}
	public void resetEnc(){
		encL.reset();
		encR.reset();
	}
	
	public void initDefaultCommand() {
		// Set the default command for a subsystem here.
		setDefaultCommand(new DriveControl_Command());
	}

}