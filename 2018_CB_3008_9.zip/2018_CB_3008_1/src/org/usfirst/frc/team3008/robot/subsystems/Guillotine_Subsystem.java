package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.OI;
import org.usfirst.frc.team3008.robot.RobotMap;
import org.usfirst.frc.team3008.robot.commands.GuillotineUp_Command;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.command.WaitUntilCommand;

public class Guillotine_Subsystem extends Subsystem{
	static Spark LiftSpark = new Spark(9); 
	static DigitalInput liftLim1 = new DigitalInput(RobotMap.LiftLimit1);
	static DigitalInput liftLim2 = new DigitalInput(RobotMap.LiftLimit2);
	public Guillotine_Subsystem(){
	}
	
	public void Up(){ 
		LiftSpark.set(1);
	}
	public void stop(){ 
		LiftSpark.set(0);
	}
	public void Down(){ 
		LiftSpark.set(-0.50);
	}
	public void lowerTillSwitch(){
		if(liftLim2.get()) {
			LiftSpark.set(1);
		}
		else {
			LiftSpark.set(-1);
		}
	}
	public void RaiseTillScale(){
		if(liftLim2.get()) {
			LiftSpark.set(-1);
		}
		else {
			LiftSpark.set(1);
		}
	}
	public void setSpeed() {
		   LiftSpark.set(OI.getRightTrigger()-OI.getLeftTrigger());
	}
	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(new GuillotineUp_Command());
		
	}

}
