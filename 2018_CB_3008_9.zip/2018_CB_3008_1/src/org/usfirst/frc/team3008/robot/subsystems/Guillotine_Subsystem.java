package org.usfirst.frc.team3008.robot.subsystems;

import org.usfirst.frc.team3008.robot.RobotMap;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.command.WaitUntilCommand;

public class Guillotine_Subsystem extends Subsystem{
	Spark LiftS = new Spark(RobotMap.Elevator);
	DigitalInput liftLim1 = new DigitalInput(RobotMap.LiftLimit1);
	DigitalInput liftLim2 = new DigitalInput(RobotMap.LiftLimit2);
	public Guillotine_Subsystem(){
		
	}
	
	public void Up(){ 
		LiftS.set(1);
	}
	public void stop(){ 
		LiftS.set(0);
	}
	public void Down(){ 
		LiftS.set(-1);
	}
	public void lowerTillSwitch(){
		if(liftLim1.get()) {
			LiftS.set(1);
		}
		else {
			LiftS.set(-1);
		}
	}
	public void RaiseTillScale(){
		if(liftLim2.get()) {
			LiftS.set(1);
		}
		else {
			LiftS.set(-1);
		}
	}
	@Override
	protected void initDefaultCommand() {
		setDefaultCommand(null);
		
	}

}
